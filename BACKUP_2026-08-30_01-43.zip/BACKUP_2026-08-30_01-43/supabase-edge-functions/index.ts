// ============================================================================
// AuditMyTracking — Edge Function: audit-scan  (Option B, free tier)
// Deno runtime (Supabase Edge Functions)
//
// এটা টার্গেট সাইটের মূল HTML + এর ভেতরের external <script> ফাইলগুলোও
// স্ক্যান করে, তাই JS-এর ভেতরে লুকানো GTM/GA4/Meta/Ads tag ও ধরা পড়ে।
// কোনো জোর করে true সেট করা নেই — যা পাওয়া যায় তাই রিপোর্ট হয়।
// ============================================================================

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/125.0 Safari/537.36";

// একটা URL fetch করে টেক্সট ফেরত দেয়, টাইমআউট সহ
async function fetchText(url: string, timeoutMs = 8000): Promise<string> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      redirect: "follow",
      headers: { "User-Agent": UA, Accept: "text/html,application/javascript,*/*" },
    });
    if (!res.ok) return "";
    return await res.text();
  } catch {
    return "";
  } finally {
    clearTimeout(t);
  }
}

// HTML থেকে সব <script src="..."> এর URL বের করে (absolute-এ রূপান্তর সহ)
function extractScriptSrcs(html: string, baseUrl: string): string[] {
  const srcs: string[] = [];
  const re = /<script[^>]+src=["']([^"']+)["']/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html)) !== null) {
    try {
      srcs.push(new URL(m[1], baseUrl).href);
    } catch {
      /* invalid url, skip */
    }
  }
  return srcs;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });

  try {
    const { url } = await req.json();
    if (!url || typeof url !== "string") {
      return json({ error: "Missing url" }, 400);
    }

    let target = url.trim();
    if (!/^https?:\/\//i.test(target)) target = "https://" + target;

    // 1) মূল HTML আনো
    const html = await fetchText(target);
    if (!html) {
      // সত্যিকারের ব্যর্থতা — আর জোর করে "পাস" দেখাবো না
      return json({
        ok: false,
        reason: "unreachable",
        message: "Target site could not be reached or blocked the request.",
      });
    }

    // 2) প্রথম-পক্ষ ও গুরুত্বপূর্ণ external script গুলো টেনে আনো
    //    (analytics/tag সম্পর্কিত হওয়ার সম্ভাবনা আছে এমনগুলো অগ্রাধিকার)
    const scriptUrls = extractScriptSrcs(html, target);
    const interesting = scriptUrls.filter((s) =>
      /googletagmanager|gtag|analytics|fbevents|connect\.facebook|tiktok|snapchat|sc-static|pinimg|licdn|ads-twitter|clarity|hotjar|stape|sst|sgtm/i.test(
        s,
      )
    );

    // GTM container-ID খুঁজে, container script-ও fetch করার জন্য বানাও
    const gtmIds = [...html.matchAll(/GTM-[A-Z0-9]+/g)].map((x) => x[0]);
    const gtmContainerUrls = [...new Set(gtmIds)].map(
      (id) => `https://www.googletagmanager.com/gtm.js?id=${id}`,
    );

    // সর্বোচ্চ ১২টি sub-request (ফ্রি টিয়ার বন্ধুসুলভ রাখতে)
    const toFetch = [...new Set([...interesting, ...gtmContainerUrls])].slice(0, 12);
    const fetched = await Promise.all(toFetch.map((u) => fetchText(u, 6000)));

    // সব সোর্স একসাথে জোড়া দিয়ে একটা বড় স্ক্যান-স্ট্রিং
    const blob = [html, ...fetched].join("\n");

    // 3) সত্যিকারের detection
    const detect = {
      gtm: /googletagmanager\.com\/gtm\.js|GTM-[A-Z0-9]+/i.test(blob),
      ga4: /gtag\/js\?id=G-[A-Z0-9]+|['"]config['"]\s*,\s*['"]G-[A-Z0-9]{6,}|G-[A-Z0-9]{8,}/i.test(
        blob,
      ),
      googleAds: /AW-[0-9]{6,}|googleadservices\.com\/pagead\/conversion|google_conversion_id/i.test(
        blob,
      ),
      consentMode: /gtag\s*\(\s*['"]consent['"]|['"]ad_user_data['"]|['"]ad_personalization['"]/i.test(
        blob,
      ),
      meta: /connect\.facebook\.net\/[a-zA-Z_]+\/fbevents\.js|fbq\s*\(\s*['"]init['"]/i.test(
        blob,
      ),
      tiktok: /analytics\.tiktok\.com\/i18n\/pixel\/events\.js|ttq\.load\s*\(/i.test(blob),
      snapchat: /sc-static\.net\/scevent\.min\.js|snaptr\s*\(\s*['"]init['"]/i.test(blob),
      pinterest: /s\.pinimg\.com\/ct\/core\.js|pintrk\s*\(\s*['"]load['"]/i.test(blob),
      linkedin: /snap\.licdn\.com\/li\.lms-analytics\/insight\.min\.js|_linkedin_partner_id/i.test(
        blob,
      ),
      twitter: /static\.ads-twitter\.com\/uwt\.js|twq\s*\(\s*['"]config['"]/i.test(blob),
      serverSide: /load\.sst\.|sgtm\.|data-stape|first-party\/sst|\/gtm\.js\?id=GTM-[A-Z0-9]+.{0,80}(gtm_auth|gtm_preview)/i.test(
        blob,
      ),
    };

    // ধরা-পড়া আসল ID গুলো (রিপোর্টে দেখানোর জন্য, বিশ্বাসযোগ্যতা বাড়ায়)
    const found = {
      gtmIds: [...new Set(gtmIds)],
      ga4Ids: [...new Set([...blob.matchAll(/G-[A-Z0-9]{8,}/g)].map((x) => x[0]))].slice(0, 5),
      adsIds: [...new Set([...blob.matchAll(/AW-[0-9]{6,}/g)].map((x) => x[0]))].slice(0, 5),
    };

    return json({
      ok: true,
      url: target,
      detect,
      found,
      scannedScripts: toFetch.length,
    });
  } catch (e) {
    return json({ error: String(e) }, 500);
  }
});

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, "Content-Type": "application/json" },
  });
}
