# Supabase Dashboard দিয়ে Edge Function Deploy — টার্মিনাল ছাড়া

কোনো CLI লাগবে না। পুরোটা ব্রাউজারে।

## ধাপ ১ — Supabase Dashboard খোলো
1. https://supabase.com/dashboard এ লগইন করো।
2. তোমার প্রজেক্ট `flpmaegkhkxxaitlgglv` সিলেক্ট করো।

## ধাপ ২ — নতুন Edge Function বানাও
1. বাঁ পাশের মেনু থেকে **Edge Functions** এ ক্লিক করো।
2. **Deploy a new function** → **Via Editor** (বা "Create a new function") বেছে নাও।
3. Function এর নাম দাও ঠিক এটাই: `audit-scan`
   (নাম আলাদা হলে frontend-এর AUDIT_ENDPOINT-ও বদলাতে হবে)

## ধাপ ৩ — কোড বসাও
1. এডিটরে ডিফল্ট যা কোড আছে সব **মুছে ফেলো**।
2. `index.ts` ফাইলের পুরো কোড কপি করে পেস্ট করো।
3. **Deploy** বাটনে ক্লিক করো। ১-২ মিনিটে deploy হবে।

## ধাপ ৪ — খুব জরুরি: JWT verification বন্ধ করো
তোমার সাইট পাবলিক, তাই ইউজার লগইন টোকেন ছাড়াই অডিট চালাবে। ডিফল্টে
Edge Function টোকেন চায়, যা এখানে দরকার নেই।

1. Function টা deploy হওয়ার পর, ওটার **Settings** এ যাও।
2. **Verify JWT with legacy secret** (বা "Enforce JWT Verification") অপশনটা
   **OFF** করে দাও।
3. Save করো।

> এটা না করলে frontend থেকে কল করলে 401 error আসবে।

## ধাপ ৫ — টেস্ট করো
Deploy হওয়ার পর URL হবে:
`https://flpmaegkhkxxaitlgglv.supabase.co/functions/v1/audit-scan`

ব্রাউজার কনসোল (যেকোনো পেজে F12) খুলে এটা চালাও:

```js
fetch("https://flpmaegkhkxxaitlgglv.supabase.co/functions/v1/audit-scan", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ url: "https://www.shopify.com" })
}).then(r => r.json()).then(console.log);
```

সঠিক হলে এমন response পাবে:
```json
{ "ok": true, "url": "...", "detect": { "gtm": true, "ga4": true, ... }, "found": {...} }
```

## ধাপ ৬ — Frontend আপডেট করো
`audit-js-changes.md` অনুযায়ী তোমার `js/audit.js` ফাইলে ৩টা পরিবর্তন করো,
GitHub-এ commit/push করো। GitHub Pages নিজে থেকেই রিডিপ্লয় হবে।

---

## একটা বাস্তবতা জেনে রাখো
Option B ফ্রি এবং তোমার এখনকার নকল-detection বন্ধ করবে, কিন্তু:
- যেসব সাইট server-side rendering ছাড়া পুরোপুরি JS দিয়ে tag ইনজেক্ট করে
  (যেমন কিছু SPA/Consent-manager), সেখানে ১০০% ধরা নাও পড়তে পারে।
- এটা raw HTML + external script স্ক্যান করে, browser render করে না।
- ট্রাফিক বাড়লে Option A (real rendering API) যোগ করলে নির্ভুলতা ৯৫%+ হবে।

এই সীমাবদ্ধতা সত্ত্বেও এটা তোমার আগের সংস্করণের চেয়ে অনেক সৎ ও নির্ভরযোগ্য।
