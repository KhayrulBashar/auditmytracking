# audit.js — যা যা বদলাতে হবে

## পরিবর্তন ১: `fetchTargetSource` ফাংশন পুরো মুছে ফেলো

নিচের পুরো ব্লকটা **ডিলিট** করো (audit.js-এ আছে):

```js
async function fetchTargetSource(targetUrl) {
  try {
    const res1 = await fetch(`https://api.allorigins.win/get?url=${encodeURIComponent(targetUrl)}`, { cache: "no-store" });
    if (res1.ok) {
      const data = await res1.json();
      if (data && data.contents && data.contents.length > 200) {
        return data.contents;
      }
    }
  } catch (e) {}

  try {
    const res2 = await fetch(`https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(targetUrl)}`, { cache: "no-store" });
    if (res2.ok) {
      const text = await res2.text();
      if (text && text.length > 200) return text;
    }
  } catch (e) {}

  return "";
}
```

এর জায়গায় এই নতুন ফাংশন বসাও (তোমার Supabase project ref অলরেডি বসানো আছে):

```js
// Supabase Edge Function থেকে আসল detection আনে
const AUDIT_ENDPOINT =
  "https://flpmaegkhkxxaitlgglv.supabase.co/functions/v1/audit-scan";

async function fetchAuditResult(targetUrl) {
  try {
    const res = await fetch(AUDIT_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: targetUrl }),
    });
    if (!res.ok) return null;
    return await res.json();
  } catch (e) {
    return null;
  }
}
```

---

## পরিবর্তন ২: `runAudit`-এর ভেতরের detection অংশ বদলাও

`window.runAudit` ফাংশনে এই পুরো ব্লকটা খুঁজে বের করো:

```js
  let rawHtml = await fetchTargetSource(url);
  let src = rawHtml || "";

  let hasGTM = /googletagmanager\.com\/gtm\.js|GTM-[A-Z0-9]+/i.test(src);
  let hasGA4 = /gtag\s*\(\s*['"]config['"]\s*,\s*['"]G-[A-Z0-9]+['"]|G-[A-Z0-9]{8,}|google-analytics\.com/i.test(src);
  let hasGoogleAds = /AW-[0-9]{6,}|googleadservices\.com\/pagead\/conversion|google_conversion_id/i.test(src);
  let hasConsentMode = /gtag\s*\(\s*['"]consent['"]|ad_storage|ad_user_data/i.test(src);
  let hasMeta = /connect\.facebook\.net\/[a-z_A-Z]+\/fbevents\.js|fbq\s*\(\s*['"]init['"]/i.test(src);
  let hasTikTok = /analytics\.tiktok\.com\/i18n\/pixel\/events\.js|ttq\.load\s*\(/i.test(src);
  let hasSnapchat = /sc-static\.net\/scevent\.min\.js|snaptr\s*\(\s*['"]init['"]/i.test(src);
  let hasPinterest = /s\.pinimg\.com\/ct\/core\.js|pintrk\s*\(\s*['"]load['"]/i.test(src);
  let hasLinkedIn = /snap\.licdn\.com\/li\.lms-analytics\/insight\.min\.js|_linkedin_partner_id/i.test(src);
  let hasTwitter = /static\.ads-twitter\.com\/uwt\.js|twq\s*\(\s*['"]config['"]/i.test(src);
  let hasServerSide = /load\.sst\.|sgtm\.|sst\.|ss\.|capig\.|data-stape/i.test(src);

  if (!src) {
    hasGTM = true;
    hasGA4 = true;
    hasGoogleAds = true;
    hasMeta = true;
    hasServerSide = true;
    hasConsentMode = false;
    hasTikTok = false;
  }

  const { platform, formType } = detectPlatformAndForm(rawHtml, url);
```

এবং সেটাকে এটা দিয়ে **রিপ্লেস** করো:

```js
  const auditResp = await fetchAuditResult(url);

  // সাইট রিচ করা না গেলে — আর জোর করে "পাস" দেখাবো না, সৎ error দেখাবো
  if (!auditResp || auditResp.ok === false) {
    auditBtn.disabled = false;
    auditBtn.innerText = "Run Free Audit";
    auditBtn.classList.remove("animate-brand-wave");
    statusMsg.classList.add("hidden");
    stopProcessingAnimation();
    window.showNotificationModal(
      "error",
      "Scan Failed",
      (auditResp && auditResp.message) ||
        "We couldn't reach that site. Please check the URL and try again."
    );
    return;
  }

  const d = auditResp.detect;
  const hasGTM = d.gtm;
  const hasGA4 = d.ga4;
  const hasGoogleAds = d.googleAds;
  const hasConsentMode = d.consentMode;
  const hasMeta = d.meta;
  const hasTikTok = d.tiktok;
  const hasSnapchat = d.snapchat;
  const hasPinterest = d.pinterest;
  const hasLinkedIn = d.linkedin;
  const hasTwitter = d.twitter;
  const hasServerSide = d.serverSide;

  // platform detection এখন backend HTML ছাড়া চলবে না, তাই hint হিসেবে রাখো
  const platform = window.lastDetectedPlatform || "Custom Coded";
  const formType = window.lastDetectedForm || "Standard / Native Form";
```

---

## পরিবর্তন ৩ (ঐচ্ছিক কিন্তু জরুরি): নিজের কনভার্সন ট্র্যাকিং

`runAudit` ফাংশনের একদম শুরুতে (URL validate হওয়ার পরে, `window.currentAuditedUrl = url;` লাইনের ঠিক নিচে) এটা যোগ করো:

```js
  window.dataLayer.push({
    event: "run_audit",
    audit_url: url,
  });
```

আর ফাংশনের শেষে, রিপোর্ট দেখানোর পরে (`results.scrollIntoView` লাইনের ঠিক আগে) এটা যোগ করো:

```js
  window.dataLayer.push({
    event: "audit_complete",
    audit_url: url,
    audit_score: score,
    issues_found: fixableIssuesCount,
  });
```
